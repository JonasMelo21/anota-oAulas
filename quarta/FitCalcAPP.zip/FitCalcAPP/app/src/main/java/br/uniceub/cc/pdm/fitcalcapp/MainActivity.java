package br.uniceub.cc.pdm.fitcalcapp;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    Button btnAbrirCalculadoraIMC;
    Button btnAbrirCalculadoraPesoIdeal;
    Button btnAbrirCalculadoraAlturaIdeal;

    // Views da calculadora de peso ideal
    RadioGroup radioGroupPesoIdealSexo;
    RadioButton radioMasculinoPesoIdeal, radioFemininoPesoIdeal;
    EditText editTextAltura;
    Button buttonCalcularPesoIdeal, buttonVoltarPesoIdeal;
    TextView textViewResultadoPesoIdeal;

    // Views da calculadora de altura ideal
    RadioGroup radioGroupAlturaIdealSexo;
    RadioButton radioMasculinoAlturaIdeal, radioFemininoAlturaIdeal;
    EditText editTextPeso;
    Button buttonCalcularAlturaIdeal, buttonVoltarAlturaIdeal;
    TextView textViewResultadoAlturaIdeal;

    // Views da calculadora IMC
    RadioGroup radioGroupIMC;
    RadioButton radMasculinoIMC, radFemininoIMC;
    EditText editTextAlturaIMC, editTextPesoIMC;
    Button btnCalcularIMC, btnVoltarIMC;
    TextView textViewResultadoIMC;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.tela_principal);

        // Configuração dos botões da página principal
        btnAbrirCalculadoraIMC = findViewById(R.id.btn_abrir_calculadora_imc);
        btnAbrirCalculadoraPesoIdeal = findViewById(R.id.btn_abrir_calculadora_peso_ideal);
        btnAbrirCalculadoraAlturaIdeal = findViewById(R.id.btn_abrir_calculadora_altura_ideal);

        btnAbrirCalculadoraIMC.setOnClickListener(view -> abrirCalculadoraIMC());
        btnAbrirCalculadoraPesoIdeal.setOnClickListener(view -> abrirCalculadoraPesoIdeal());
        btnAbrirCalculadoraAlturaIdeal.setOnClickListener(view -> abrirCalculadoraAlturaIdeal());
    }


    private void abrirCalculadoraIMC() {
        setContentView(R.layout.calculadora_imc);

        // Inicialização das views da calculadora IMC
        radioGroupIMC = findViewById(R.id.radio_group_sexo);
        radMasculinoIMC = findViewById(R.id.rad_masculino);
        radFemininoIMC = findViewById(R.id.rad_feminino);
        editTextAlturaIMC = findViewById(R.id.editText_altura); // Agora está correto
        editTextPesoIMC = findViewById(R.id.editText_peso); // Agora está correto
        btnCalcularIMC = findViewById(R.id.btn_calcular_imc);
        textViewResultadoIMC = findViewById(R.id.textView_resultado);
        btnVoltarIMC = findViewById(R.id.btn_calculadora_imc_tela_principal);

        btnCalcularIMC.setOnClickListener(view -> calcularIMC());
        btnVoltarIMC.setOnClickListener(view -> setContentView(R.layout.tela_principal));
    }


    private void calcularIMC() {
        String alturaStr = editTextAlturaIMC.getText().toString();
        String pesoStr = editTextPesoIMC.getText().toString();

        if (alturaStr.isEmpty() || pesoStr.isEmpty()) {
            textViewResultadoIMC.setText("Por favor, insira a altura e o peso.");
            return;
        }

        double altura = Double.parseDouble(alturaStr);
        double peso = Double.parseDouble(pesoStr);
        double imc = peso / (altura * altura);

        textViewResultadoIMC.setText("IMC: " + String.format("%.2f", imc));
    }

    private void abrirCalculadoraPesoIdeal() {
        setContentView(R.layout.calculadora_peso_ideal);

        // Inicialização das views da calculadora de peso ideal
        radioGroupPesoIdealSexo = findViewById(R.id.radio_group_sexo);
        radioMasculinoPesoIdeal = findViewById(R.id.radio_masculino);
        radioFemininoPesoIdeal = findViewById(R.id.radio_feminino);
        editTextAltura = findViewById(R.id.editText_altura);
        buttonCalcularPesoIdeal = findViewById(R.id.button_calcular);
        textViewResultadoPesoIdeal = findViewById(R.id.textView_resultado);
        buttonVoltarPesoIdeal = findViewById(R.id.button_voltar);

        buttonCalcularPesoIdeal.setOnClickListener(view -> calcularPesoIdeal());
        buttonVoltarPesoIdeal.setOnClickListener(view -> setContentView(R.layout.tela_principal));
    }

    private void calcularPesoIdeal() {
        String alturaStr = editTextAltura.getText().toString();
        if (alturaStr.isEmpty()) {
            textViewResultadoPesoIdeal.setText("Por favor, insira a altura.");
            return;
        }

        double altura = Double.parseDouble(alturaStr);
        double pesoIdeal;

        if (radioMasculinoPesoIdeal.isChecked()) {
            pesoIdeal = (72.7 * altura) - 58;
        } else if (radioFemininoPesoIdeal.isChecked()) {
            pesoIdeal = (62.1 * altura) - 44.7;
        } else {
            textViewResultadoPesoIdeal.setText("Por favor, selecione um sexo.");
            return;
        }

        textViewResultadoPesoIdeal.setText("Peso Ideal: " + String.format("%.2f", pesoIdeal) + " kg");
    }

    private void abrirCalculadoraAlturaIdeal() {
        setContentView(R.layout.calculadora_altura_ideal);

        // Inicialização das views da calculadora de altura ideal
        radioGroupAlturaIdealSexo = findViewById(R.id.asdf);
        radioMasculinoAlturaIdeal = findViewById(R.id.radio_masculino);
        radioFemininoAlturaIdeal = findViewById(R.id.radio_feminino);
        editTextPeso = findViewById(R.id.editText_peso);
        buttonCalcularAlturaIdeal = findViewById(R.id.button_calcular);
        textViewResultadoAlturaIdeal = findViewById(R.id.textView_resultado);
        buttonVoltarAlturaIdeal = findViewById(R.id.button_voltar);

        buttonCalcularAlturaIdeal.setOnClickListener(view -> calcularAlturaIdeal());
        buttonVoltarAlturaIdeal.setOnClickListener(view -> setContentView(R.layout.tela_principal));
    }

    private void calcularAlturaIdeal() {
        String pesoStr = editTextPeso.getText().toString();
        if (pesoStr.isEmpty()) {
            textViewResultadoAlturaIdeal.setText("Por favor, insira o peso.");
            return;
        }

        double peso = Double.parseDouble(pesoStr);
        double alturaIdeal;

        if (radioMasculinoAlturaIdeal.isChecked()) {
            alturaIdeal = (peso + 58) / 72.7;
        } else if (radioFemininoAlturaIdeal.isChecked()) {
            alturaIdeal = (peso + 44.7) / 62.1;
        } else {
            textViewResultadoAlturaIdeal.setText("Por favor, selecione um sexo.");
            return;
        }

        textViewResultadoAlturaIdeal.setText("Altura Ideal: " + String.format("%.2f", alturaIdeal) + " m");
    }
}
